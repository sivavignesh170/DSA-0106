#include "playlist_noconst.h"
void show(const Playlist& p) { std::cout << p[1] << '\n'; }
int main() { Playlist pl{"A", "B"}; show(pl); }
