#include <chrono>
#include <string>
#include "track_time.h"
struct Heavy {                                        // class with a costly copy (owns heap memory)
    std::string label = std::string(64, 'x'); int v = 0;
    Heavy& operator++() { ++v; return *this; }
    Heavy operator++(int) { Heavy old = *this; ++v; return old; }
};
template <class T, class F> double run(T& x, F f) {
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000000; ++i) { f(x); asm volatile("" : "+m"(x) :: "memory"); }
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}
int main() {
    Time t1, t2; Heavy h1, h2;
    std::cout << "Time  prefix  : " << run(t1, [](Time& x) { ++x; }) << " ms\n";
    std::cout << "Time  postfix : " << run(t2, [](Time& x) { x++; }) << " ms\n";
    std::cout << "Heavy prefix  : " << run(h1, [](Heavy& x) { ++x; }) << " ms\n";
    std::cout << "Heavy postfix : " << run(h2, [](Heavy& x) { x++; }) << " ms\n";
}
