#include "track_time.h"
#include "playlist.h"
void show(const Playlist& p) { std::cout << "const read p[1] = " << p[1] << '\n'; }   // needs const operator[]
int main() {
    std::cout << "--- 1. a = t++ and b = ++t ---\n";
    Time t(0, 0, 10);
    Time a = t++;
    std::cout << "after a = t++ : a = " << a << ", t = " << t << '\n';
    Time b = ++t;
    std::cout << "after b = ++t : b = " << b << ", t = " << t << '\n';

    std::cout << "--- 2. roll-over ---\n";
    Time r1(0, 0, 59), r2(0, 59, 59), r3(1, 59, 59);
    std::cout << r1 << " -> " << ++r1 << '\n';
    std::cout << r2 << " -> " << ++r2 << '\n';
    std::cout << r3 << " -> " << ++r3 << '\n';

    std::cout << "--- 3. == and < ---\n";
    std::cout << std::boolalpha << (Time(0, 1, 0) == Time(0, 0, 60)) << ' ' << (Time(0, 2, 59) < Time(0, 3, 0)) << ' ' << (Time(1) < Time(0, 59, 59)) << '\n';

    std::cout << "--- 4. Playlist [] ---\n";
    Playlist pl{"Kuthu Fire", "Ocean Drive", "Night Bus"};
    std::cout << "pl[0] = " << pl[0] << "\npl[2] = " << pl[2] << '\n';
    pl[1] = "Ocean Drive (Remix)";                      // non-const version, assignable
    show(pl);                                           // const version
    std::cout << "pl[-1]   -> " << pl[-1] << '\n';
    std::cout << "pl[size] -> " << pl[pl.size()] << '\n';

    std::cout << "--- 5. playback simulation (track length 0:05, 2 tracks) ---\n";
    Playlist q{"Song A", "Song B"};
    Time length(0, 0, 5), pos;
    for (int i = 0; i < q.size(); ++i) {
        pos = Time();
        std::cout << "Playing " << q[i] << ": ";
        while (pos < length) { std::cout << pos << ' '; ++pos; }
        std::cout << "| ended at " << pos << (pos == length ? " (== length)" : "") << '\n';
    }
}
