#include <chrono>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
class P {
    std::vector<std::string> t; std::string bad = "<invalid>";
public:
    P() : t(1000, "track") {}
    int size() const { return (int)t.size(); }
    const std::string& unchecked(int i) const { return t[i]; }
    const std::string& checked(int i) const { if (i < 0 || i >= size()) { std::cerr << "Error\n"; return bad; } return t[i]; }
    const std::string& at(int i) const { if (i < 0 || i >= size()) throw std::out_of_range("playlist index"); return t[i]; }
};
template <class F> double run(F f, size_t& sink) {
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000000; ++i) sink += f(i % 1000).size();
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}
int main() {
    P p; size_t s = 0;
    std::cout << "unchecked []   : " << run([&](int i) -> const std::string& { return p.unchecked(i); }, s) << " ms\n";
    std::cout << "checked  []    : " << run([&](int i) -> const std::string& { return p.checked(i); }, s) << " ms\n";
    std::cout << "at() (throws)  : " << run([&](int i) -> const std::string& { return p.at(i); }, s) << " ms\n";
    std::cout << "(sink " << s << ")\n";
    try { p.at(-1); } catch (const std::out_of_range& e) { std::cout << "at(-1) threw: " << e.what() << '\n'; }
    try { p.at(p.size()); } catch (const std::out_of_range& e) { std::cout << "at(size) threw: " << e.what() << '\n'; }
}
