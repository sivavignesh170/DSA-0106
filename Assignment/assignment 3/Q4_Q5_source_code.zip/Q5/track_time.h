#pragma once
#include <iostream>
class Time {
    int sec;                                           // total seconds = single source of truth
public:
    Time(int h = 0, int m = 0, int s = 0) : sec(h * 3600 + m * 60 + s) {}
    Time& operator++() { ++sec; return *this; }                       // prefix : increment, return *this
    Time operator++(int) { Time old = *this; ++sec; return old; }     // postfix: dummy int, return OLD copy
    bool operator==(const Time& o) const { return sec == o.sec; }
    bool operator<(const Time& o) const { return sec < o.sec; }
    friend std::ostream& operator<<(std::ostream& os, const Time& t) {
        int h = t.sec / 3600, m = t.sec / 60 % 60, s = t.sec % 60;
        if (h) os << h << ':' << (m < 10 ? "0" : "") << m << ':';
        else   os << m << ':';
        return os << (s < 10 ? "0" : "") << s;
    }
};
