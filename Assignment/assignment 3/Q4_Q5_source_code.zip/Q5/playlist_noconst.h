#pragma once
#include <iostream>
#include <string>
#include <vector>
class Playlist {
    std::vector<std::string> tracks;
    std::string bad = "<invalid track>";               // returned after an error, so the program can go on
public:
    Playlist(std::initializer_list<std::string> t) : tracks(t) {}
    int size() const { return (int)tracks.size(); }
    std::string& operator[](int i) {                   // non-const: can be used on the left of =
        if (i < 0 || i >= size()) { std::cerr << "Error: index " << i << " out of range [0," << size() - 1 << "]\n"; return bad; }
        return tracks[i];
    }
};
