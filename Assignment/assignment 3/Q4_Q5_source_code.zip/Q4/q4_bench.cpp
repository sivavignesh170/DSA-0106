#include <chrono>
#include <iomanip>
#include "money.h"
int main() {
    const int N = 1000000;
    double d = 0.0; Money m;
    for (int i = 0; i < N; ++i) { d += 0.10; m += Money(0, 10); }      // 1,000,000 additions of Rs 0.10
    std::cout << std::fixed << std::setprecision(10);
    std::cout << "expected      : 100000.0000000000\n";
    std::cout << "double sum    : " << d << "\n";
    std::cout << "double error  : " << d - 100000.0 << "\n";
    std::cout << "double == 100000.0 ? " << std::boolalpha << (d == 100000.0) << "\n";
    std::cout << "Money sum     : " << m << "  (paise = " << m.totalPaise() << ")\n";
    std::cout << "Money == Rs 100000 ? " << (m == Money(100000)) << "\n";
}
