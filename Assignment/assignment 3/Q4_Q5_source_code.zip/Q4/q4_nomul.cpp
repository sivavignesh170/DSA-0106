#include "money.h"
int main() { Money a(5), b(2); Money c = a * b; (void)c; }
