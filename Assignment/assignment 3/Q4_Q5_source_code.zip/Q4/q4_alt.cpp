#include <iostream>
// Version A: member operator+     Version B: friend (non-member) operator+
class MoneyA { public: long long p; MoneyA(long long r = 0, int q = 0) : p(r*100+q) {}
    MoneyA operator+(const MoneyA& o) const { return MoneyA(0, 0).set(p + o.p); }
    MoneyA set(long long v) { p = v; return *this; } };
class MoneyB { public: long long p; MoneyB(long long r = 0, int q = 0) : p(r*100+q) {}
    friend MoneyB operator+(const MoneyB& a, const MoneyB& b) { MoneyB t; t.p = a.p + b.p; return t; } };
int main() {
    MoneyA a(5); MoneyB b(5);
    std::cout << (a + 100).p << '\n';          // member: works  (100 converts for the RIGHT operand)
    std::cout << (b + 100).p << '\n';          // friend: works
    std::cout << (100 + b).p << '\n';          // friend: works  (100 converts for the LEFT operand too)
#ifdef TRY_MEMBER_LEFT
    std::cout << (100 + a).p << '\n';          // member: ERROR
#endif
}
