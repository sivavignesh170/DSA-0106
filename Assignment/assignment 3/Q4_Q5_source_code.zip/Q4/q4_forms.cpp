#include <chrono>
#include <iostream>
struct M1 { long long p; M1 operator+(const M1& o) const { return {p + o.p}; } };                 // member
struct M2 { long long p; friend M2 operator+(const M2& a, const M2& b) { return {a.p + b.p}; } }; // friend
struct M3 { long long p; }; M3 add(const M3& a, const M3& b) { return {a.p + b.p}; }             // named
template <class T, class F> double run(F f) {
    T acc{0}, one{1}; auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 100000000; ++i) { acc = f(acc, one); asm volatile("" : "+m"(acc) :: "memory"); }
    auto t1 = std::chrono::steady_clock::now();
    if (acc.p != 100000000) std::cout << "BAD\n";
    return std::chrono::duration<double, std::milli>(t1 - t0).count();
}
int main() {
    std::cout << "sizeof: " << sizeof(M1) << ' ' << sizeof(M2) << ' ' << sizeof(M3) << " bytes\n";
    std::cout << "member : " << run<M1>([](M1 a, M1 b) { return a + b; }) << " ms\n";
    std::cout << "friend : " << run<M2>([](M2 a, M2 b) { return a + b; }) << " ms\n";
    std::cout << "named  : " << run<M3>([](M3 a, M3 b) { return add(a, b); }) << " ms\n";
}
