#pragma once
#include <iostream>
#include <string>

class Money {
    long long paise;                                   // single source of truth: whole paise
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}
    static Money fromPaise(long long p) { Money m; m.paise = p; return m; }
    long long totalPaise() const { return paise; }

    Money operator+(const Money& o) const { return fromPaise(paise + o.paise); }   // new object
    Money operator-(const Money& o) const { return fromPaise(paise - o.paise); }   // new object
    Money& operator+=(const Money& o) { paise += o.paise; return *this; }         // modifies this
    Money& operator-=(const Money& o) { paise -= o.paise; return *this; }
    Money operator*(long long k) const { return fromPaise(paise * k); }            // price x qty
    Money operator*(const Money&) const = delete;   // Rs x Rs: no meaning

    bool operator==(const Money& o) const { return paise == o.paise; }
    bool operator!=(const Money& o) const { return !(*this == o); }
    bool operator<(const Money& o) const { return paise < o.paise; }
    bool operator>(const Money& o) const { return o < *this; }
    bool operator<=(const Money& o) const { return !(o < *this); }
    bool operator>=(const Money& o) const { return !(*this < o); }

    friend std::ostream& operator<<(std::ostream& os, const Money& m) {
        long long a = m.paise < 0 ? -m.paise : m.paise;
        return os << (m.paise < 0 ? "-" : "") << "Rs " << a / 100 << '.'
                  << (a % 100 < 10 ? "0" : "") << a % 100;
    }
    friend std::istream& operator>>(std::istream& is, Money& m) {   // reads e.g. 120.75
        std::string s; if (!(is >> s)) return is;
        bool neg = s[0] == '-'; if (neg) s.erase(0, 1);
        size_t d = s.find('.');
        std::string r = s.substr(0, d), p = d == std::string::npos ? "00" : s.substr(d + 1);
        if (r.empty() || p.size() != 2 || r.find_first_not_of("0123456789") != std::string::npos
            || p.find_first_not_of("0123456789") != std::string::npos) {
            is.setstate(std::ios::failbit); return is;
        }
        long long v = std::stoll(r) * 100 + std::stoi(p);
        m = fromPaise(neg ? -v : v);
        return is;
    }
};
