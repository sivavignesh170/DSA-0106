#include <iomanip>
#include <sstream>
#include "money.h"
// ---- Bill WITHOUT operator overloading (named functions) ----
struct RawMoney { long long paise; };
RawMoney add(RawMoney a, RawMoney b) { return {a.paise + b.paise}; }
RawMoney sub(RawMoney a, RawMoney b) { return {a.paise - b.paise}; }
RawMoney mul(RawMoney a, long long k) { return {a.paise * k}; }
void print(RawMoney a) { std::cout << "Rs " << a.paise / 100 << '.' << (a.paise % 100 < 10 ? "0" : "") << a.paise % 100; }

int main() {
    std::cout << "--- 1. carry: Rs 0.75 + Rs 0.50 ---\n";
    Money x(0, 75), y(0, 50);
    std::cout << x << " + " << y << " = " << x + y << "  (paise = " << (x + y).totalPaise() << ")\n";

    std::cout << "--- 2. negative result: Rs 0.50 - Rs 0.75 ---\n";
    Money n = y - x;
    std::cout << n << "  (paise = " << n.totalPaise() << ", n < Rs 0 : " << std::boolalpha << (n < Money(0)) << ")\n";

    std::cout << "--- 3. compiler translation ---\n";
    Money a(120, 75), b(79, 25);
    std::cout << "a + b            = " << a + b << '\n';
    std::cout << "a.operator+(b)   = " << a.operator+(b) << '\n';
    std::cout << "operator<<(std::cout, a) prints: "; operator<<(std::cout, a) << '\n';

    std::cout << "--- 4. bill with overloaded operators ---\n";
    Money tea(12, 50), sandwich(45, 75), water(20), coupon(10), paid(150);
    Money total = tea * 3 + sandwich * 2 + water;
    total -= coupon;
    std::cout << "Total  : " << total << "\nPaid   : " << paid << "\nChange : " << paid - total << '\n';
    std::cout << "Enough : " << (paid >= total) << '\n';

    std::cout << "--- 5. same bill with named functions ---\n";
    RawMoney t{1250}, s{4575}, w{2000}, c{1000}, p{15000};
    RawMoney tot = sub(add(add(mul(t, 3), mul(s, 2)), w), c);
    std::cout << "Total  : "; print(tot); std::cout << "\nChange : "; print(sub(p, tot)); std::cout << '\n';

    std::cout << "--- 6. operator>> ---\n";
    std::istringstream in("120.75 -3.05 abc");
    Money r1, r2, r3;
    in >> r1 >> r2;
    std::cout << "read " << r1 << " and " << r2 << '\n';
    in >> r3;
    std::cout << "bad input 'abc' -> failbit set: " << in.fail() << '\n';

    std::cout << "--- 7. operator== / != / < ---\n";
    std::cout << (Money(2, 0) == Money(0, 200)) << ' ' << (Money(1) != Money(2)) << ' ' << (Money(1) < Money(2)) << '\n';
}
