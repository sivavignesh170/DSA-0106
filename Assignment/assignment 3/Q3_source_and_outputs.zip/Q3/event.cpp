#include "event.hpp"

int main() {
    std::cout << "--- 1. event on the stack ---\n";
    Event hall("Stack-Hall", 3, 5);
    std::cout << "book(0,0)=" << hall.book(0, 0) << " book(0,1)=" << hall.book(0, 1)
              << " book(2,4)=" << hall.book(2, 4)
              << " book(0,0) again=" << hall.book(0, 0) << "\n";
    std::cout << "cancel(0,1)=" << hall.cancel(0, 1)
              << " cancel(1,1) not booked=" << hall.cancel(1, 1)
              << " book(3,0) out of range=" << hall.book(3, 0) << "\n";
    hall.show();

    {
        std::cout << "--- 2. event inside a block ---\n";
        Event blk("Block-Hall", 2, 4);
        blk.book(1, 3);
        std::cout << "leaving the block\n";
    }

    std::cout << "--- 3. event on the heap (new/delete) ---\n";
    Event* h = new Event("Heap-Hall", 2, 3);
    h->book(1, 2);
    std::cout << "calling delete\n";
    delete h;

    std::cout << "--- 4. zero rows ---\n";
    {
        Event z("Empty-Hall", 0, 10);
        std::cout << "capacity=" << z.capacity() << " book(0,0)=" << z.book(0, 0) << "\n";
        z.show();
    }

    std::cout << "--- 5. negative rows ---\n";
    try { Event bad("Bad-Hall", -1, 5); }
    catch (const std::invalid_argument& e) { std::cout << "rejected: " << e.what() << "\n"; }

    std::cout << "--- end of main ---\n";
}
