// event.hpp - Auditorium seat map with a dynamic constructor and a destructor
#pragma once
#include <iostream>
#include <stdexcept>
#include <string>

class Event {
    std::string name_;
    int rows_;
    int seatsPerRow_;
    char** seats_;   // array of row pointers; each row is its own new char[]
    int booked_;

public:
    // Dynamic constructor: sizes differ per event, so the memory comes from the heap.
    Event(const std::string& name, int rows, int seatsPerRow)
        : name_(name), rows_(rows), seatsPerRow_(seatsPerRow), seats_(nullptr), booked_(0)
    {
        if (rows < 0 || seatsPerRow < 0)
            throw std::invalid_argument("rows and seats per row must not be negative");
        std::cout << "[ctor] " << name_ << " " << rows_ << "x" << seatsPerRow_ << "\n";
        if (rows_ > 0) {
            seats_ = new char*[rows_];            // allocation 1: the row pointers
            int r = 0;
            try {
                for (; r < rows_; ++r) {          // allocations 2..rows+1: one per row
                    seats_[r] = new char[seatsPerRow_];
                    for (int s = 0; s < seatsPerRow_; ++s) seats_[r][s] = '.';
                }
            } catch (...) {                       // no destructor runs if a constructor throws
                for (int i = 0; i < r; ++i) delete[] seats_[i];
                delete[] seats_;
                throw;
            }
        }
    }

    // The destructor prints the closing summary, then releases every allocation.
    ~Event() {
        int cap = rows_ * seatsPerRow_;
        std::cout << "[dtor] " << name_ << ": closing summary - capacity " << cap
                  << ", booked " << booked_ << ", free " << cap - booked_ << "\n";
        for (int r = 0; r < rows_; ++r) delete[] seats_[r];   // every row (they are arrays)
        delete[] seats_;                                      // then the pointer array
    }

    // Owns raw memory: copying would double-delete (Rule of Three), so forbid it.
    Event(const Event&) = delete;
    Event& operator=(const Event&) = delete;

    bool inRange(int r, int s) const {
        return r >= 0 && r < rows_ && s >= 0 && s < seatsPerRow_;
    }

    bool book(int r, int s) {
        if (!inRange(r, s) || seats_[r][s] == 'X') return false;
        seats_[r][s] = 'X'; ++booked_; return true;
    }
    bool cancel(int r, int s) {
        if (!inRange(r, s) || seats_[r][s] != 'X') return false;
        seats_[r][s] = '.'; --booked_; return true;
    }
    int booked() const { return booked_; }
    int capacity() const { return rows_ * seatsPerRow_; }

    void show() const {
        std::cout << "  seat map of " << name_ << " (. free, X booked):\n";
        if (rows_ == 0) { std::cout << "  (no rows)\n"; return; }
        for (int r = 0; r < rows_; ++r) {
            std::cout << "  row " << r << ": ";
            for (int s = 0; s < seatsPerRow_; ++s) std::cout << seats_[r][s];
            std::cout << "\n";
        }
    }
};
