// measure.cpp - memory and time for three seat-map layouts
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <malloc.h>
#include <memory>
#include <new>
#include <vector>

#pragma GCC diagnostic ignored "-Wmismatched-new-delete"

static std::size_t g_count = 0, g_bytes = 0;
static bool g_on = false;
void* operator new(std::size_t n) {
    if (g_on) { ++g_count; g_bytes += n; }
    void* p = std::malloc(n ? n : 1);
    if (!p) throw std::bad_alloc();
    return p;
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

struct Rows {                       // A: array of row pointers (the Q3 design)
    int R, S; char** m;
    Rows(int r, int s) : R(r), S(s), m(new char*[r]) { for (int i = 0; i < r; ++i) { m[i] = new char[s]; for (int j = 0; j < s; ++j) m[i][j] = '.'; } }
    ~Rows() { for (int i = 0; i < R; ++i) delete[] m[i]; delete[] m; }
    char& at(int r, int s) { return m[r][s]; }
};
struct Flat {                       // B: one block, index r*S+s
    int R, S; char* m;
    Flat(int r, int s) : R(r), S(s), m(new char[(std::size_t)r * s]) { for (std::size_t i = 0; i < (std::size_t)r * s; ++i) m[i] = '.'; }
    ~Flat() { delete[] m; }
    char& at(int r, int s) { return m[(std::size_t)r * S + s]; }
};
struct Vec {                        // C: vector<vector<char>>
    std::vector<std::vector<char>> m;
    Vec(int r, int s) : m(r, std::vector<char>(s, '.')) {}
    char& at(int r, int s) { return m[r][s]; }
};

template <class T>
void run(const char* name, int R, int S) {
    struct mallinfo2 m0 = mallinfo2(); std::size_t before = m0.uordblks + m0.hblkhd;
    g_count = g_bytes = 0; g_on = true;
    auto t0 = std::chrono::steady_clock::now();
    std::unique_ptr<T> p(new T(R, S));
    auto t1 = std::chrono::steady_clock::now();
    g_on = false;
    std::size_t cnt = g_count - 1, bytes = g_bytes - sizeof(T);       // ignore the holder object itself
    struct mallinfo2 m1 = mallinfo2(); std::size_t inuse = m1.uordblks + m1.hblkhd - before;
    long long sum = 0;
    int reps = (R * (long long)S >= 1000000) ? 20 : 2000;
    if (R * (long long)S < 10000) reps = 200000;
    auto t2 = std::chrono::steady_clock::now();
    for (int k = 0; k < reps; ++k)
        for (int r = 0; r < R; ++r)
            for (int s = 0; s < S; ++s) { char& c = p->at(r, s); c = (c == '.') ? 'X' : '.'; sum += c; }
    auto t3 = std::chrono::steady_clock::now();
    double build_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    double ns_per = std::chrono::duration<double, std::nano>(t3 - t2).count() / ((double)reps * R * S);
    std::cout << name << " | " << R << "x" << S << " | allocs=" << cnt << " | requested=" << bytes
              << " B | heap_in_use=" << inuse << " B | build=" << build_ms << " ms | access=" << ns_per
              << " ns/seat | chk=" << sum << "\n";
}

int main() {
    int dims[3][2] = {{10, 20}, {100, 200}, {1000, 2000}};
    for (auto& d : dims) {
        run<Rows>("A rows-of-pointers", d[0], d[1]);
        run<Flat>("B flat-block      ", d[0], d[1]);
        run<Vec >("C vector<vector>  ", d[0], d[1]);
        std::cout << "\n";
    }
}
