#include <iostream>
int main() {
    char* row = new char[20];   // allocated as an array
    delete row;                 // BUG on purpose: should be delete[] row
    std::cout << "done\n";
}
