#include "event.hpp"
int main() {
    Event* h = new Event("Leaky-Hall", 4, 10);
    h->book(1, 1);
    // BUG on purpose: no delete h;  -> destructor never runs, summary never printed
}
