# Assignment 3 (CO3) - Q3: Dynamic Constructors and Destructors

Name: Sanjeev S | Register No.: 192511267 | BE CSE, SIMATS Engineering
Compiler: g++ 13.3.0 (Ubuntu 24.04)
Compile command: `g++ -std=c++17 -Wall -Wextra <file>.cpp -o <name>`
Sanitizer builds add: `-g -fsanitize=address` (leak-only check: `-fsanitize=leak`)

## Files and how to run
| File | What it is | Run |
|---|---|---|
| event.hpp / event.cpp | Event class (dynamic constructor, destructor, book/cancel) and the stack / block / heap / zero-row tests | `g++ -std=c++17 -Wall -Wextra event.cpp -o event && ./event` |
| leak.cpp | Missing `delete` (on purpose) | `g++ -std=c++17 -g -fsanitize=address leak.cpp -o leak && ./leak` |
| mismatch.cpp | `delete` used on `new[]` (on purpose) | `g++ -std=c++17 -g -fsanitize=address mismatch.cpp -o mm && ./mm` |
| PREDICTION.txt, predict.cpp | Predict-the-output: prediction written first, then the program | `g++ -std=c++17 -Wall -Wextra predict.cpp -o predict && ./predict` |
| measure.cpp | Memory and time of three seat-map layouts | `g++ -std=c++17 -Wall -Wextra -O2 measure.cpp -o measure && ./measure` |
| out_*.txt | Saved outputs | - |

## Result
All events are released (sanitizer clean for event.cpp). leak.cpp reports 128 bytes in 6 allocations; mismatch.cpp reports alloc-dealloc-mismatch. Predicted output matched the actual output exactly: `+A +B -B copyAc use -Ac +P -P end -A `.
