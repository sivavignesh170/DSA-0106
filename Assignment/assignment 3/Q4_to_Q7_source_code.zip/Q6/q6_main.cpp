#include <string>
#include "text.h"
int main() {
    std::cout << "--- 1. basic ---\n";
    Text a("Hello"), b(", "), c("SMS!");
    Text m = a + b + c;                                  // copy ctor not needed (elided)
    std::cout << m << "  (size " << m.size() << ")\n";
    Text copy = m; Text asg; asg = m;
    std::cout << (copy == m) << (asg == m) << (a != b) << (a == a) << '\n';
    asg = Text("changed");
    Text g = "Hi " + a;                                  // literal on the LEFT works because + is a friend
    std::cout << g << " (\"Hi \" + Text)\n";
    std::cout << "m still: " << m << " | asg: " << asg << " (independent)\n";

    std::cout << "--- 2. empty messages ---\n";
    Text e1, e2("");
    std::cout << "empty size " << e1.size() << ", e1 == e2: " << (e1 == e2) << ", [" << e1 + e2 << "] size " << (e1 + e2).size() << '\n';
    std::cout << "a + empty == a: " << (a + e1 == a) << ", empty + a == a: " << (e1 + a == a) << '\n';

    std::cout << "--- 3. long messages ---\n";
    std::string big(1000000, 'x');
    Text L1(big.c_str()), L2(big.c_str());
    Text L3 = L1 + L2;
    std::cout << "1,000,000 + 1,000,000 chars -> size " << L3.size() << ", equal to 2,000,000 x's: " << (L3 == Text(std::string(2000000, 'x').c_str())) << '\n';

    std::cout << "--- 4. self-assignment ---\n";
    Text s("keep me"); Text& r = s;
    s = r; std::cout << "after s = s : " << s << '\n';
    s += s; std::cout << "after s += s: " << s << '\n';

    std::cout << "--- 5. chained assignment ---\n";
    Text x, y, z; x = y = z = Text("chain"); std::cout << x << ' ' << y << ' ' << z << '\n';
}
