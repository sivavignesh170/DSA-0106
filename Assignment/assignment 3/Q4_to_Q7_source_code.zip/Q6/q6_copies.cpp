#include "text.h"
int main() {
    Text a("aaaaaaaaaa"), b("bbbbbbbbbb"), c("cccccccccc");        // n1 = n2 = n3 = 10
    Text::copies = 0; Text::chars = 0;
    Text r = a + b + c;
    std::cout << "a + b + c : copy-ctor calls = " << Text::copies << ", characters copied = " << Text::chars << ", result size " << r.size() << '\n';
}
