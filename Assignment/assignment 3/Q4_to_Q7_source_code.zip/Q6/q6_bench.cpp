#include <chrono>
#include <string>
#include "text.h"
template <class F> double ms(F f) { auto t0 = std::chrono::steady_clock::now(); f(); return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); }
int main() {
    const int N = 100000; size_t sink = 0;
    std::cout << "Text   t = t + \"x\"   : " << ms([&] { Text t; Text p("x"); for (int i = 0; i < N; ++i) t = t + p; sink += t.size(); }) << " ms\n";
    std::cout << "Text   t += \"x\"      : " << ms([&] { Text t; Text p("x"); for (int i = 0; i < N; ++i) t += p; sink += t.size(); }) << " ms\n";
    std::cout << "string s = s + \"x\"   : " << ms([&] { std::string s; for (int i = 0; i < N; ++i) s = s + "x"; sink += s.size(); }) << " ms\n";
    std::cout << "string s += \"x\"      : " << ms([&] { std::string s; for (int i = 0; i < N; ++i) s += "x"; sink += s.size(); }) << " ms\n";
    std::cout << "(sink " << sink << ")\n";
}
