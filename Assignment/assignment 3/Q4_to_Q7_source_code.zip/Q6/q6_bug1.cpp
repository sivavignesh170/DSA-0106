#include <cstring>
#include <iostream>
class Text {
    size_t n; char* d;
public:
    Text(const char* s) : n(std::strlen(s)), d(new char[n + 1]) { std::memcpy(d, s, n + 1); }
    Text& operator=(const Text& o) {            // BUG: no self-assignment guard
        delete[] d; d = new char[o.n + 1]; std::memcpy(d, o.d, o.n + 1); n = o.n; return *this;
    }
    ~Text() { delete[] d; }
    const char* c_str() const { return d; }
};
int main() { Text t("hello"); Text& r = t; t = r; std::cout << "after t = t : [" << t.c_str() << "]\n"; }
