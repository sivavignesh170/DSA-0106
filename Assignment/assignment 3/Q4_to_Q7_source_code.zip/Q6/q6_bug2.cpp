#include <cstring>
#include <iostream>
class Text {
    size_t n; char* d;
public:
    Text(const char* s) : n(std::strlen(s)), d(new char[n + 1]) { std::memcpy(d, s, n + 1); }
    ~Text() { delete[] d; }
    friend Text operator+(const Text& a, const Text& b) {
        Text r(""); delete[] r.d;
        r.n = a.n + b.n; r.d = new char[r.n];            // BUG: forgot + 1 for the '\0'
        std::memcpy(r.d, a.d, a.n); std::memcpy(r.d + a.n, b.d, b.n + 1);
        return r;
    }
};
int main() { Text a("Hello"), b("World"); Text c = a + b; std::cout << "done\n"; }
