#pragma once
#include <cstring>
#include <iostream>
class Text {
    size_t n;                                   // declared first, so initialised first
    char*  d;                                   // heap array of n + 1 chars (with '\0')
    Text(size_t len, char) : n(len), d(new char[len + 1]) { d[len] = '\0'; }   // private: blank of given length
public:
    static inline int copies = 0;               // copy-constructor calls (for the experiment)
    static inline size_t chars = 0;             // characters copied by copy/+/+=
    Text(const char* s = "") : n(std::strlen(s)), d(new char[n + 1]) { std::memcpy(d, s, n + 1); }
    Text(const Text& o) : n(o.n), d(new char[o.n + 1]) { std::memcpy(d, o.d, n + 1); ++copies; chars += n; }
    Text& operator=(const Text& o) {
        if (this == &o) return *this;                         // self-assignment guard
        char* nd = new char[o.n + 1];                         // build the new array first
        std::memcpy(nd, o.d, o.n + 1); chars += o.n;
        delete[] d;                                           // then release the old one
        d = nd; n = o.n;
        return *this;
    }
    ~Text() { delete[] d; }
    size_t size() const { return n; }
    const char* c_str() const { return d; }

    Text& operator+=(const Text& o) {                         // safe even for t += t
        Text r(n + o.n, 0);
        std::memcpy(r.d, d, n); std::memcpy(r.d + n, o.d, o.n); chars += n + o.n;
        std::swap(d, r.d); std::swap(n, r.n);                 // r now owns the old array and frees it
        return *this;
    }
#ifndef ALT_PLUS
    friend Text operator+(const Text& a, const Text& b) {     // builds the result once
        Text r(a.n + b.n, 0);
        std::memcpy(r.d, a.d, a.n); std::memcpy(r.d + a.n, b.d, b.n); chars += a.n + b.n;
        return r;
    }
#else
    friend Text operator+(Text a, const Text& b) { a += b; return a; }   // alternative: += on a copy
#endif
    friend bool operator==(const Text& a, const Text& b) { return a.n == b.n && std::memcmp(a.d, b.d, a.n) == 0; }
    friend bool operator!=(const Text& a, const Text& b) { return !(a == b); }
    friend std::ostream& operator<<(std::ostream& os, const Text& t) { return os << t.d; }
};
