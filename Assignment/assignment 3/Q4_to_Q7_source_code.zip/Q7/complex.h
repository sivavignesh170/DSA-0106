#pragma once
#include <cmath>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <stdexcept>
class Complex {
    double re, im;
public:
    Complex() : re(0), im(0) {}                                  // 0 + 0j
    Complex(double r) : re(r), im(0) {}                          // real only: resistor R + 0j (implicit, so 2 * z works)
    Complex(double r, double i) : re(r), im(i) {}                // full rectangular form
    double real() const { return re; }
    double imag() const { return im; }
    double abs() const { return std::hypot(re, im); }            // magnitude sqrt(re^2 + im^2)

    Complex operator-() const { return {-re, -im}; }
    Complex& operator+=(const Complex& o) { re += o.re; im += o.im; return *this; }
    Complex& operator-=(const Complex& o) { re -= o.re; im -= o.im; return *this; }
    Complex& operator*=(const Complex& o) { double r = re * o.re - im * o.im; im = re * o.im + im * o.re; re = r; return *this; }
    Complex& operator/=(const Complex& o) {
        double den = o.re * o.re + o.im * o.im;
        if (den == 0.0) throw std::domain_error("division by zero impedance");
        double r = (re * o.re + im * o.im) / den; im = (im * o.re - re * o.im) / den; re = r;
        return *this;
    }
    friend Complex operator+(Complex a, const Complex& b) { return a += b; }
    friend Complex operator-(Complex a, const Complex& b) { return a -= b; }
    friend Complex operator*(Complex a, const Complex& b) { return a *= b; }
    friend Complex operator/(Complex a, const Complex& b) { return a /= b; }
    friend bool operator==(const Complex& a, const Complex& b) {            // tolerance, not exact ==
        auto close = [](double x, double y) { return std::fabs(x - y) <= 1e-9 * std::fmax(1.0, std::fmax(std::fabs(x), std::fabs(y))); };
        return close(a.re, b.re) && close(a.im, b.im);
    }
    friend bool operator!=(const Complex& a, const Complex& b) { return !(a == b); }
    friend std::ostream& operator<<(std::ostream& os, const Complex& z) {   // rectangular form  a + bj
        std::ostringstream t; t << std::fixed << std::setprecision(4) << z.re << (z.im < 0 ? " - " : " + ") << std::fabs(z.im) << 'j';
        return os << t.str();
    }
};
// impedance helpers: R, inductor jwL, capacitor -j/(wC); parallel of two = Z1*Z2/(Z1+Z2)
inline Complex resistor(double R) { return Complex(R); }
inline Complex inductor(double w, double L) { return Complex(0, w * L); }
inline Complex capacitor(double w, double C) { return Complex(0, -1.0 / (w * C)); }
inline Complex parallel(const Complex& a, const Complex& b) { return (a * b) / (a + b); }
