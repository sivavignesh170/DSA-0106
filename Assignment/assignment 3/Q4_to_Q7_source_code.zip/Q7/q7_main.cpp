#include "complex.h"
int checks = 0, passed = 0;
void check(const char* name, const Complex& got, const Complex& want) {
    ++checks; bool ok = got == want; passed += ok;
    std::cout << (ok ? "PASS " : "FAIL ") << name << ": got " << got << ", expected " << want << '\n';
}
int main() {
    std::cout << "--- 1. operator tests (by hand) ---\n";
    Complex a(3, 4), b(1, -2);
    check("(3+4j) + (1-2j)", a + b, Complex(4, 2));
    check("(3+4j) - (1-2j)", a - b, Complex(2, 6));
    check("(3+4j) * (1-2j)", a * b, Complex(11, -2));
    check("(3+4j) / (1-2j)", a / b, Complex(-1, 2));
    check("2 * (3+4j)   [real converts]", 2 * a, Complex(6, 8));
    std::cout << "|3+4j| = " << a.abs() << "  (expected 5)\n";

    std::cout << "--- 2. series RLC: R=30 ohm, L=0.05 H, C=50 uF, w=1000 rad/s ---\n";
    const double w = 1000, R = 30, L = 0.05, C = 50e-6;
    Complex ZR = resistor(R), ZL = inductor(w, L), ZC = capacitor(w, C);
    std::cout << "ZR = " << ZR << "   ZL = " << ZL << "   ZC = " << ZC << '\n';
    Complex Zs = ZR + ZL + ZC;
    std::cout << "Z series   = " << Zs << "   |Z| = " << std::fixed << std::setprecision(4) << Zs.abs() << " ohm\n";
    check("series Z", Zs, Complex(30, 30));

    std::cout << "--- 3. parallel RLC (same R, L, C) ---\n";
    Complex Zp = parallel(parallel(ZR, ZL), ZC);
    std::cout << "R || L     = " << parallel(ZR, ZL) << '\n';
    std::cout << "Z parallel = " << Zp << "   |Z| = " << Zp.abs() << " ohm\n";
    check("parallel Z", Zp, Complex(30 / 1.81, -27 / 1.81));   // exact: Y = (1 + 0.9j)/30
    Complex Yp = Complex(1) / ZR + Complex(1) / ZL + Complex(1) / ZC;   // cross-check by admittance
    std::cout << "cross-check 1/(1/R + 1/jwL + 1/Zc) = " << Complex(1) / Yp << '\n';

    std::cout << "--- 4. division by zero ---\n";
    try { Complex z = Complex(1, 2) / Complex(0, 0); std::cout << z << '\n'; }
    catch (const std::domain_error& e) { std::cout << "caught: " << e.what() << '\n'; }
    try { Complex z = parallel(inductor(w, L), -inductor(w, L)); std::cout << z << '\n'; }   // ideal parallel LC at resonance
    catch (const std::domain_error& e) { std::cout << "caught (parallel +j50 and -j50, sum is 0): " << e.what() << '\n'; }
    std::cout << "\n" << passed << " of " << checks << " checks passed\n";
}
