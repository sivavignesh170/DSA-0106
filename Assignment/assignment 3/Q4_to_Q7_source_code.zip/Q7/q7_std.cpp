#include <complex>
#include <iostream>
using namespace std::complex_literals;
int main() {
    const double w = 1000;
    std::complex<double> ZR = 30.0, ZL(0, w * 0.05), ZC(0, -1 / (w * 50e-6));
    std::complex<double> Zs = ZR + ZL + ZC;
    auto par = [](std::complex<double> a, std::complex<double> b) { return (a * b) / (a + b); };
    std::complex<double> Zp = par(par(ZR, ZL), ZC);
    std::cout << "series   " << Zs << " |Z| = " << std::abs(Zs) << '\n';
    std::cout << "parallel " << Zp << " |Z| = " << std::abs(Zp) << '\n';
    std::cout << "(1+2j)/(0+0j)  = " << std::complex<double>(1, 2) / std::complex<double>(0, 0) << "   (no exception)\n";
    std::cout << "par(+j50,-j50) = " << par(ZL, -ZL) << "   (no exception)\n";
}
