#include <complex>
#include "complex.h"
int main() {
    Complex a(1e200, 1e200), b(1e200, 1e200);
    std::complex<double> sa(1e200, 1e200), sb(1e200, 1e200);
    std::cout << "(1e200+1e200j)/(1e200+1e200j)\n  my Complex      : " << a.real() << " / " << (a / b).real() << " , " << (a / b).imag() << '\n';
    std::cout << "  std::complex    : " << (sa / sb) << "   (expected (1,0))\n";
    Complex c(1e-200, 1e-200), d(1e-200, 1e-200);
    std::complex<double> sc(1e-200, 1e-200), sd(1e-200, 1e-200);
    std::cout << "(1e-200+1e-200j)/(1e-200+1e-200j)\n  my Complex      : ";
    try { std::cout << (c / d).real() << " , " << (c / d).imag() << '\n'; } catch (const std::exception& e) { std::cout << "threw: " << e.what() << '\n'; }
    std::cout << "  std::complex    : " << (sc / sd) << "   (expected (1,0))\n";
}
