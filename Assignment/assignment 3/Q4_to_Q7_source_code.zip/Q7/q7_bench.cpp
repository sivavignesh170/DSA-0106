#include <chrono>
#include <complex>
#include "complex.h"
template <class T> double run(T z, T k) {
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 50000000; ++i) { z = (z * k + k) / (k + T(1)); asm volatile("" : "+m"(z) :: "memory"); }
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}
int main() {
    std::cout << "sizeof(Complex) = " << sizeof(Complex) << ", sizeof(std::complex<double>) = " << sizeof(std::complex<double>) << " bytes\n";
    std::cout << "my Complex   : " << run(Complex(1, 1), Complex(0.5, 0.25)) << " ms\n";
    std::cout << "std::complex : " << run(std::complex<double>(1, 1), std::complex<double>(0.5, 0.25)) << " ms\n";
}
